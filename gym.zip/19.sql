-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2019-04-09 19:44:28
-- 服务器版本： 5.5.62
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `19`
--

-- --------------------------------------------------------

--
-- 表的结构 `u_admin`
--

CREATE TABLE IF NOT EXISTS `u_admin` (
  `id` int(5) NOT NULL COMMENT '管理员id',
  `username` char(30) NOT NULL COMMENT '管理员名称',
  `password` char(40) NOT NULL COMMENT '管理员密码',
  `mpw` varchar(40) NOT NULL COMMENT '明文密码',
  `ip` varchar(255) NOT NULL COMMENT '最后登录ip'
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `u_admin`
--

INSERT INTO `u_admin` (`id`, `username`, `password`, `mpw`, `ip`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', '1.1.1.1');

-- --------------------------------------------------------

--
-- 表的结构 `u_crows`
--

CREATE TABLE IF NOT EXISTS `u_crows` (
  `id` bigint(20) NOT NULL COMMENT '记录id',
  `uid` bigint(20) NOT NULL COMMENT '用户id',
  `jf` varchar(20) NOT NULL DEFAULT '0' COMMENT '当前积分',
  `ymd` varchar(20) NOT NULL COMMENT '签到时间20180111'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `u_crows`
--

INSERT INTO `u_crows` (`id`, `uid`, `jf`, `ymd`) VALUES
(3, 32, '25', '20181126'),
(4, 30, '11', '20181126'),
(5, 30, '5', '20181128'),
(6, 36, '21', '20181128'),
(7, 37, '21', '20190409');

-- --------------------------------------------------------

--
-- 表的结构 `u_users`
--

CREATE TABLE IF NOT EXISTS `u_users` (
  `id` mediumint(9) NOT NULL COMMENT 'id号',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(50) NOT NULL COMMENT '用户密码',
  `integral` bigint(20) NOT NULL DEFAULT '20' COMMENT '用户积分',
  `zc_time` bigint(20) NOT NULL COMMENT '注册时间',
  `sex` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1男0女 默认 1',
  `ip` varchar(25) NOT NULL DEFAULT '0' COMMENT '用户最后登陆ip',
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `ytime` char(50) NOT NULL DEFAULT '周六周日'
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `u_users`
--

INSERT INTO `u_users` (`id`, `username`, `password`, `integral`, `zc_time`, `sex`, `ip`, `email`, `ytime`) VALUES
(33, 'ddd', 'ddd', 20, 1543366493, 0, '0', 'ddd@qq.com', '周六周日'),
(32, 'ccc', 'ccc', 24, 1543366446, 1, '::1', 'ccc@qq.com', '周六周日'),
(30, 'aaa11', 'aaa11', 4, 1543366416, 1, '::1', 'aaa11@qq.com', '周六周日'),
(31, 'bbb', 'bbb', 1, 1543366430, 0, '::1', 'bbb@qq.com', '周六周日'),
(34, 'eee', 'eee', 0, 1543370523, 0, '0', 'eee@qq.com', '周六周日'),
(35, 'fff', 'fff', 0, 1543370565, 0, '0', 'fff@qq.com', '周六周日'),
(36, 'chaodada', 'chaodada', 16, 1543380600, 1, '::1', 'chaodada@qq.com', ''),
(37, 'admin', 'admin', 1500, 1554798694, 1, '0.0.0.0', '姬', '周六周日'),
(39, '', '', 20, 1554802588, 1, '0.0.0.0', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `u_xiaos`
--

CREATE TABLE IF NOT EXISTS `u_xiaos` (
  `id` bigint(20) NOT NULL COMMENT '自增id',
  `uid` bigint(20) NOT NULL COMMENT '用户id',
  `jf` varchar(20) NOT NULL DEFAULT '0' COMMENT '当前积分',
  `ymd` varchar(10) NOT NULL COMMENT '消费时间20180111'
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `u_xiaos`
--

INSERT INTO `u_xiaos` (`id`, `uid`, `jf`, `ymd`) VALUES
(2, 32, '29', '1543375510'),
(3, 32, '28', '1543375551'),
(4, 32, '27', '1543375627'),
(5, 32, '26', '1543375630'),
(6, 32, '25', '1543375641'),
(7, 32, '24', '1543375829'),
(8, 30, '10', '1543375956'),
(9, 30, '9', '1543375958'),
(10, 30, '8', '1543375960'),
(11, 30, '7', '1543376799'),
(12, 30, '6', '1543376970'),
(13, 30, '5', '1543376973'),
(14, 30, '4', '1543380134'),
(15, 30, '4', '1543380338'),
(16, 36, '20', '1543380738'),
(17, 36, '19', '1543380741'),
(18, 36, '18', '1543380743'),
(19, 36, '17', '1543380746'),
(20, 36, '16', '1543381225'),
(21, 37, '20', '1554798710'),
(22, 37, '19', '1554798723'),
(23, 37, '18', '1554798985'),
(24, 37, '17', '1554800613'),
(25, 37, '16', '1554801426'),
(26, 37, '15', '1554801524');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `u_admin`
--
ALTER TABLE `u_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `u_crows`
--
ALTER TABLE `u_crows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_users`
--
ALTER TABLE `u_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_xiaos`
--
ALTER TABLE `u_xiaos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `u_admin`
--
ALTER TABLE `u_admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT COMMENT '管理员id',AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `u_crows`
--
ALTER TABLE `u_crows`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录id',AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `u_users`
--
ALTER TABLE `u_users`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT 'id号',AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `u_xiaos`
--
ALTER TABLE `u_xiaos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
